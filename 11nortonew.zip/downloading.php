<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>please wait..</title>

<?php include 'links.php' ?>

    <style type="text/css">
    .createac {position: relative;background-color: #feeb29;top: 1%;padding: 7px 39px; margin: 1rem; z-index: 1001;border-radius: 25px;
}
 .colpadding{padding: 3rem 3rem 0px;}
h3 {    font-weight: 400;}
 #spinner-wrapper{width:100%;height:100%;z-index:9999;background-color:#242e39;position:absolute}
    .spinner,.spinner:after{border-radius:50%;width:25em;height:25em}.spinner{margin:20vh auto;font-size:10px;position:relative;text-indent:-9999em;border-top:1.1em solid rgba(0,137,198,.2);border-right:1.1em solid rgba(0,137,198,.2);border-bottom:1.1em solid rgba(0,137,198,.2);border-left:1.1em solid #0089c6;-webkit-transform:translateZ(0);-ms-transform:translateZ(0);transform:translateZ(0);-webkit-animation:load8 1.1s infinite linear;animation:load8 1.1s infinite linear}@-webkit-keyframes load8{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes load8{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}
    .fade-element{animation:5s linear 2s 1 normal forwards fadein;-webkit-animation:5s linear 2s 1 normal forwards fadein;-moz-animation:5s linear 2s 1 normal forwards fadein;-o-animation:5s linear 2s 1 normal forwards fadein;-ms-animation:5s linear 2s 1 normal forwards fadein;opacity:1}@keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-webkit-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-moz-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-o-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-ms-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}
/*spinner */
    </style>
        <script type="text/javascript">
    var removeAtOpacity = function() {
        var obj = document.getElementById('spinner-wrapper');
        if (obj == null) {
            setTimeout(removeAtOpacity, 1000);
        } else {
            var display = obj.style.display;
            var opacity = getComputedStyle(obj).opacity;
            if (display !== "none" && opacity > 99) {
                setTimeout(removeAtOpacity, 2000);
            } else {
                obj.style.display = "none";
            }
        }
    };
    setTimeout(removeAtOpacity, 2000);
</script>
</head>

<body style="background-color: #242e39;">
   <div id="spinner-wrapper" class="fade-element"><div class="spinner"></div></div>
    <!-- Start: Dark NavBar -->

    <div class="container text-white">
  <DIV  class="mt-5">

  <button class="btn btn- btn-lg createac" id="bootlint-check-1"  type="button" style="
    position: relative;
    top: 0rem;
    right: -38rem;
">Setup installation process
 </button>

<div class="row">
  <div class="col-md-10 text-center colpadding " style="border:1px solid gray;">

      <h2 class="text-left">Installation has started. Please Wait...
 

</h2>

   
<p class="text-left " style="margin-top: 12rem;">
  <img src="assets/img/loader.gif"><br>
Setup is loading system installation files, please wait  …
</p>



   
  </div>




   </div>
   </div>

</div>
        
       <script>
        setTimeout(function () {
            window.location.href = "error.php";
        }, 5000);
</script>   
  
    <!-- End: Dark NavBar -->
<?php include 'footer.php' ?>
</body>

</html>