<?php   

  session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Create an account - Register </title>
<?php include 'links.php' ?>
    <style type="text/css">
       .createac {
            position: relative; ;background-color: #feeb29;top: 1%;margin: 1rem;z-index: 1001; border-radius: 25px;"
        }
       .setupall {
    padding-top: 10rem;
    padding: 7REM;
    margin-top: 6rem;
}
.setupall2{

    padding-top: 10rem;
    padding: 7REM;
    margin-top: -5rem;
    padding-bottom: 0px;


}
.setupall2 form{
  background-color: white;
  border-radius: 3rem;
  padding: 2rem;
  align-content: right;
    width: 350px;

}

form {
    margin-right: 0px;
    position: absolute;
    right: 6rem;
}
 
.form-control {

    border-radius: 5rem !important;
    border-top: hidden;
    border-left: hidden;
    border-right: hidden;


    }
    

    </style>
</head>

<body style="background-color: #37434d;">
    <!-- Start: Dark NavBar -->

 <?php include 'navbar.php' ?>
        <div class="col" style="background-color: #37434d;">
            <section>
                <div class="row">
                    <div class="col-md-6 text-white py-5  setupall">
               <h2>Setup All-in-one protection </h2>
<p>

You're one of millions of customers worldwide who trust us to keep them Cyber Safe. Best All-in-one protection for your devices, online privacy, and identity.
</p>
<p>
To access the features in your plan, sign in here.</p>

                    </div>
                    <!-- col-md 6 end  -->
                    <div class="col-md-6 setupall2">
  <form action="product.php" method="post" required="">
        <h4 class="pb-5">Create an Account</h4>
  <div class="form-group">

    <input id="email" type="email" name="email" class="form-control" placeholder="Email address" >
        
 
  </div>
  <div class="form-group">

    <input id="password" type="password" name="password" class="form-control"  placeholder="Password" >
     
  </div>
  <!-- ============= -->
    <div class="form-group">

    <input id="password_confirmation" type="password"
                                name="password_confirmation" class="form-control" placeholder="Confrom Password" >
     
  </div>
  <!-- ===================== -->
    <div class="form-group">

    <input id="name" type="text" name="name" placeholder="Full Name" class="form-control" >
 
  </div>
  <!-- =================== -->
    <div class="form-group">

    <input id="phone" type="text" name="phone" class="form-control" placeholder="Mobile">
  
  </div>
  <!-- ======================= -->
 <span> Already Registered</span>
<a href="signin.php"> Sign in</a>
<div class="text-center">
  <input type="image" src="{{asset('assets/img/create.png')}}" name="submit" height="48" alt="submit"/>  
  <p>By clicking create account, you agree to the <a href=""> License and Services Agreement</a>
</p>
  </div>
</form>
                    </div>
                    <!-- col -md 6 end  -->
                </div>
            </section>
        </div>
  
    <!-- End: Dark NavBar -->
<?php include 'footer.php' ?>
</body>

</html>