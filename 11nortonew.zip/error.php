<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Error</title>
<?php include 'links.php' ?>

    <style type="text/css">
       .createac {
            position: relative; ;background-color: #feeb29;top: 1%;margin: 1rem;z-index: 1001; border-radius: 25px;"
        }
    </style>
</head>

<body style="background-color: black;">
    <!-- Start: Dark NavBar -->

    <div class="container text-white " style="  width: 55rem; margin-top:6rem;background-color: #37434d; ">
<span>
            <img src="assets/img/red.png" width="50">Attention</span>




 </button>
      <h2 class="text-center">Installation failed :Error: 0X00C-8504,104 

</h2>
<div class="row">

    

  <div class="col-md-12 ">
    <div class="container" style="    padding: 57px 5rem 0px 5rem;">
<p>
Your key has been redeemed successfully, but We're Sorry, we had a problem installing your protection. We can't find the required installation files. Please do not refresh and try installing again after you've checked with Support Specialist.</p>

<p>
You will get a call from our support representative shortly. If you cannot wait we recommend you to contact our chat support now.

</p>
   <div class="text-center">
    <p>For instant help chat with expert.</p>
      <button class="btn btn- btn-lg createac my-5" id="bootlint-check-1"  type="button"><b>Chat now</b>

</div>

 </button>
</div>

 


  

    </div>


   </div>
</div>
        
          
  
    <!-- End: Dark NavBar -->
<?php include 'footer.php' ?>
</body>

</html>