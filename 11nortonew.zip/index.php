 <?php   
  session_start();
         ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home</title>
<?php include 'links.php' ?>

    <style type="text/css">
       .createac {
            position: relative; ;background-color: #feeb29;top: 1%;margin: 1rem;z-index: 1001; border-radius: 25px;"
        }
        .dot {
    border: 1px dotted yellow;
    height: 291px;
    position: absolute;
    left: 30.3rem;
    top: 7.5rem;
}
@media only screen and (max-width: 1200px) {

 .dot{
    display: none;
 }

}



    </style>
</head>

<body  style="background-color: #37434d;">
    <!-- Start: Dark NavBar -->

 <?php include 'navbar.php' ?>
        <div class="col" style="background-color: #37434d;padding-bottom: 3rem;">
            <section>
              <div class="dot"></div>
                <div class="row">
                    <div class="col">
                        <h2 class="text-center" style="background-color: #37434d;color: rgb(252,253,254);padding: 25px 0px 20px 0px;font-weight: 300;">Hi. Let's activate your protection</h2>
    <p class="text-left" style="color: rgb(247,249,251);margin-left: 35%;text-align: center;">1. sign in with your account<br></p>

                    </div>
                </div>
                <div class="row">
                    <div class="col text-center"><img src="assets/img/login.png?h=ad9f7083fd97bae736672ee77200c5e8" style="width: 10rem;"></div>
                </div>
                <div class="row">
                    <div class="col text-center">
                        <!-- Start: Bootlint Check Button -->
                        <a href="create.php"class="btn btn-warning btn-lg createac" >Create an account</a>
                        <!-- End: Bootlint Check Button -->
                        <!-- Start: Bootlint Check Button -->
                        <button class="btn btn- btn-lg createac" id="bootlint-check-1"  type="button">sign in</button>
                        <!-- End: Bootlint Check Button -->
                  
               <p class="text-left" style="padding-left: 1.5rem;  color: rgb(247,249,251);margin-left: 35%;text-align: center;">Looking to reinstall your Protection?&nbsp; <a href="#" class="text-white"> Install from your Account.</a></p>

                        <p class="text-left" style="color: rgb(247,249,251);margin-left: 35%;text-align: center;">2. Enter your product key&nbsp;</p>
                        <p class="text-left" style="color: rgb(247,249,251);margin-left: 35%;text-align: center;">3. Select your Device&nbsp;</p>
                        <p class="text-left" style="color: rgb(247,249,251);margin-left: 35%;text-align: center;">4&nbsp; Install your Protection.<br></p>
                    </div>
                </div>
            </section>
        </div>
  
    <!-- End: Dark NavBar -->
<?php include 'footer.php' ?>
</body>

</html>