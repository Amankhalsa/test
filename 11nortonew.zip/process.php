<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Processing</title>
<?php include 'links.php' ?>

    <style type="text/css">
     
.createac {
    position: relative;
    background-color: #feeb29;
    top: 1%;
    padding: 7px 39px;
    margin: 1rem;
    z-index: 1001;
    border-radius: 25px;
    ": ;
}

        .colpadding{
    padding: 7rem;
}
h2{
  margin-top: 7rem;
      font-weight: 400;
}
h3 {
    font-weight: 400;
}
    </style>
</head>

<body style="background-color: #242e39;">
    <!-- Start: Dark NavBar -->

    <div class="container text-white">
      <h2 class="text-center">Your protection is ready to download

</h2>
<div class="row">
  <div class="col-md-12 text-center colpadding">
     <div>

   <img src="assets/img/install.png">

 </div>

   

<a href="downloading.php">
    <button class="btn btn- btn-lg createac mt-5" id="bootlint-check-1"  type="button">Agree & Download

 </button>
 </a>
 <p>
   By clicking Agree & Download, you agree to the
  <a href=""> License  <br>and Services Agreement</a>

 </p>
  </div>

   </div>
</div>
        
          
  <?php include 'footer.php' ?>

</body>
</html>