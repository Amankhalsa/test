<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Install</title>
<?php include 'links.php' ?>

    <style type="text/css">
        body{
            overflow-x: hidden;
        }
.createac {
position: relative; ;background-color: #feeb29;top: 1%;margin: 1rem;z-index: 1001; border-radius: 25px;"}
.customcontrol{text-transform: uppercase;width: 50rem;height: 4.2rem; font-size: 2.5rem;}
@media only screen and (max-width: 705px) {
.customcontrol {
    text-transform: uppercase;
    width: 100%!important;
    height: 22%!important;
    /* font-size: 2.5rem; */
    overflow-x: hidden !important;}  }
.search-bar{padding:0;}
.search-bar .input-group-addon{padding:0;}
.search-bar .search-btn{
  padding:5px  12px;}
    </style>
</head>

<body style="background-color: #37434d">
    <!-- Start: Dark NavBar -->

 <?php include 'navbar.php' ?>
<div class=" text-dark text-center" style="margin-top:5rem;  background-color: white;     padding: 8rem 0px 7rem 0px;">
    <div class="row">
        <div class="col-md-6">
            <div class="container">
                    <div>

   <img src="assets/img/star.png">

 </div>
                <h5>DOWNLOAD & REINSTALL</h5>

            </div>
        </div>
<!-- ===================== -->
        <div class="col-md-6">
            <div class="container">
                    <div>

   <img src="assets/img/whiteinstall.png">

 </div>
               <h5> ENTER A NEW PRODUCT KEY</h5>

            </div>
        </div>

        
    </div>
    
</div>

       
    <!-- End: Dark NavBar -->
<?php include 'footer.php' ?>
  <script>
    function addHyphen (element) {
        let ele = document.getElementById(element.id);
        ele = ele.value.split('-').join('');    // Remove dash (-) if mistakenly entered.

        let finalVal = ele.match(/.{1,5}/g).join('-');
        document.getElementById(element.id).value = finalVal;
    }
</script>


</body>

</html>