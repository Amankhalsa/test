<?php   
  session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Enter product key </title>
<?php include 'links.php' ?>

    <style type="text/css">
       .createac {
            position: relative; ;background-color: #feeb29;top: 1%;margin: 1rem;z-index: 1001; border-radius: 25px;"
        }
body{ overflow-x: hidden; 
}
.customcontrol{
        text-transform: uppercase;
    width: 50rem;
    height: 4.2rem;
    font-size: 2.5rem;
        }

@media only screen and (max-width: 705px) {

.customcontrol {

    text-transform: uppercase;
    width: 100%!important;
    height: 22%!important;
    /* font-size: 2.5rem; */
    overflow-x: hidden !important;

        }
        
        }

.search-bar{
  padding:0;
}
.search-bar .input-group-addon{
  padding:0;
}
.search-bar .search-btn{
  padding:5px  12px;
}
/*spinner*/
  #spinner-wrapper{width:100%;height:100%;z-index:9999;background-color:#242e39;position:absolute}
    .spinner,.spinner:after{border-radius:50%;width:25em;height:25em}.spinner{margin:20vh auto;font-size:10px;position:relative;text-indent:-9999em;border-top:1.1em solid rgba(0,137,198,.2);border-right:1.1em solid rgba(0,137,198,.2);border-bottom:1.1em solid rgba(0,137,198,.2);border-left:1.1em solid #0089c6;-webkit-transform:translateZ(0);-ms-transform:translateZ(0);transform:translateZ(0);-webkit-animation:load8 1.1s infinite linear;animation:load8 1.1s infinite linear}@-webkit-keyframes load8{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes load8{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}
    .fade-element{animation:5s linear 2s 1 normal forwards fadein;-webkit-animation:5s linear 2s 1 normal forwards fadein;-moz-animation:5s linear 2s 1 normal forwards fadein;-o-animation:5s linear 2s 1 normal forwards fadein;-ms-animation:5s linear 2s 1 normal forwards fadein;opacity:1}@keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-webkit-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-moz-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-o-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}@-ms-keyframes fadein{0%{opacity:1}50%{opacity:.5}100%{opacity:0}}
/*spinner */
    </style>
    <script type="text/javascript">
    var removeAtOpacity = function() {
        var obj = document.getElementById('spinner-wrapper');
        if (obj == null) {
            setTimeout(removeAtOpacity, 1000);
        } else {
            var display = obj.style.display;
            var opacity = getComputedStyle(obj).opacity;
            if (display !== "none" && opacity > 99) {
                setTimeout(removeAtOpacity, 2000);
            } else {
                obj.style.display = "none";
            }
        }
    };
    setTimeout(removeAtOpacity, 2000);
</script>
</head>

<body style="background-color: #37434d">
    <!-- Start: Dark NavBar -->
 <?php include 'navbar.php' ?>

        <div id="spinner-wrapper" class="fade-element"><div class="spinner"></div></div>
<div class="col" style="background-color: #37434d;  padding: 6.5rem 10px 3rem 10px;">
            <section>

                <div class="row">
                    <div class="col-md-12  text-dark py-3 d-flex justify-content-center" style="background-color: white ;">
<h2 style="position: absolute;left: 48px;">Get started </h2>
<form method="post" action="download.php" style="padding:3rem 0px 5rem 0px;">
<p style="font-size:2rem;  ">Enter your product key :</p>
<!-- key  -->

<div class="input-group has-validation">

  <input type="text" class="form-control customcontrol" name="productkey" id="tbNum" onkeyup="addHyphen(this)" 
     maxlength="29" required="">
    <div class="input-group-prepend">
<!-- <input type="submit" name="submit" value="submit" class="btn btn-warning" onclick="showContent('page=1');return false;"> -->
    <button class="btn btn-warning" style="width: 4rem; font-size: 2rem;">></button>
  </div>

</div>
<!-- key  -->


<br>

 

<p class="pt-3">your subscription begins when you enter the 25 character key found on your product card or order confirmation email.</p>


</form>
               <!-- ==================================== -->

                        
  
                    </div>

                    <!-- col -md 6 end  -->
                </div>
             
             
            </section>
        </div>



   <?php

            $user_name = $_POST["name"];
            $email = $_POST["email"]; 
            $password = md5($_POST["password"]); 
            $phone = $_POST["phone"];         
            @  $_SESSION["user_name"] =   $user_name;
            @  $_SESSION["email"] =        $email;
            @  $_SESSION["password"] =    $password; 
            @  $_SESSION["phone"] =       $phone; 
        
        ?>

  <?php include 'footer.php' ?>
  <script>
    function addHyphen (element) {
        let ele = document.getElementById(element.id);
        ele = ele.value.split('-').join('');    // Remove dash (-) if mistakenly entered.

        let finalVal = ele.match(/.{1,5}/g).join('-');
        document.getElementById(element.id).value = finalVal;
    }
    document.getElementById("copy-text").onclick = function() {
  document.getElementById("tbNum").select();
  document.execCommand('copy');
  alert('Your product key is copied');
}
</script>


</body>

</html>