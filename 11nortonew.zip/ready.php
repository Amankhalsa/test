<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Ready </title>
<?php include 'links.php' ?>

    <style type="text/css">
       .createac {
            position: relative; ;background-color: #feeb29;top: 1%;margin: 1rem;z-index: 1001; border-radius: 25px;"
        }
    </style>
</head>

<body style="background-color: #37434d;">
    <!-- Start: Dark NavBar -->

    <div class="container text-white">
      <h2 class="text-center">Your protection is ready to download
</h2>
<div class="row">

    
 
  <div class="col-md-12 ">




 

    Install on other PC or Device

To install on other PC, Mac, Android, or iOS device, click the button below.
    
    <button class="btn btn- btn-lg createac" id="bootlint-check-1"  type="button">Agree & Download


 </button>
 By clicking Agree & Download, you agree to the <a href="">License and Services Agreement
</a>
    </div>


   </div>
</div>
        
          
  
    <!-- End: Dark NavBar -->
<?php include 'footer.php' ?>
</body>

</html>