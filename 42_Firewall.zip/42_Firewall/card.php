<div class="container-fluid printers_card">
	 <!-- container start  -->
	 		<p>NETWORK SECURITY</p>
	<div class="row mx-2 ">

			<div class="col-md-4 card2 my-2 py-4   ">

			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Deploy Zero-Trust Security in 	minutes
</small>
			</div>
			</div>


			<!-- <i class="fa fa-print ml-auto p-2 bd-highlight" style="font-size:28px;color:#0096d6"></i> -->
			</div>
			<div class="col-md-4 card2 my-2 py-4  ">
			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Cloud Edge Secure Access
 </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>

			</div>
			<div class="col-md-4 card2 my-2 py-4 " >

			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left">Cloud App Security
 </h3>
			<small >Visibility and security for Cloud 	Apps
</small>
			</div>
			</div>



			</div>
	</div>
	<!-- ================== 2nd row  start ============= -->
		<div class="row mx-2 ">

			<div class="col-md-4 card2 my-2 py-4   ">

			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>


			<!-- <i class="fa fa-print ml-auto p-2 bd-highlight" style="font-size:28px;color:#0096d6"></i> -->
			</div>
			<div class="col-md-4 card2 my-2 py-4  ">
			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>

			</div>
			<div class="col-md-4 card2 my-2 py-4 " >

			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>



			</div>
	</div>
	<!-- ================== 2nd row  start ============= -->
	<div class="row mx-2 ">

			<div class="col-md-4 card2 my-2 py-4   ">

			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>


			<!-- <i class="fa fa-print ml-auto p-2 bd-highlight" style="font-size:28px;color:#0096d6"></i> -->
			</div>
			<div class="col-md-4 card2 my-2 py-4  ">
			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>

			</div>
			<div class="col-md-4 card2 my-2 py-4 " >

			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>



			</div>
	</div>
	<!-- ================== 2nd row  start ============= -->
		<div class="row mx-2 ">

			<div class="col-md-4 card2 my-2 py-4   ">

			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>


			<!-- <i class="fa fa-print ml-auto p-2 bd-highlight" style="font-size:28px;color:#0096d6"></i> -->
			</div>
			<div class="col-md-4 card2 my-2 py-4  ">
			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>

			</div>
			<div class="col-md-4 card2 my-2 py-4 " >

			<div class="row"> 
			<div class="col-md-2 text-center">
				<img src="assets/img/icons/1.png">
			</div>
			<div class="col-md-10 text-left">
			<h3 class="para mb-0 text-left"> Printer setup issues & Installation </h3>
			<small >Next-generation firewall for 	<br>SMB, Enterprise, and Government</small>
			</div>
			</div>



			</div>
	</div>
	<!-- ================== 2nd row  start ============= -->

	
</div>
