    <img src="assets/img/loader.gif" class="center"  id="loader"  alt="loader image">
	<a class="navbar-brand text-dark " href="#">
		<span class="container">

		<img src="assets/img/logo-pic.png" class="img-fluid " alt="logo" style="width:70px;">
		</span>
	</a>
<nav class="navbar navbar-expand-lg navbar-light navbar-custom sticky-top ">
	<!-- <a class="navbar-brand text-light text-wrap brand_text " href="#"> </a> -->
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	  <span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
	  <ul class="navbar-nav ml-auto  pr-5">
		<li class="nav-item active">
		  <a class="nav-link" href="">Home </a>
		</li>


	
		    <li class="nav-item ">
			<a class="nav-link" href="https://printercustomsupport.com/blog/"> Buy Now   </a>
		  </li>
		     <li class="nav-item ">
			<a class="nav-link" href="https://printercustomsupport.com/blog/">Services  </a>
		  </li>
		     <li class="nav-item ">
			<a class="nav-link" href="https://printercustomsupport.com/blog/">Company  </a>
		  </li>

		  
		  <!-- dropdown end -->
		  

		  
	  </ul>

	</div>
  </nav>
  

