<?php 

$siteurl ="https://printercustomsupport.com/";

$phone ="<b>1-800-673-8163</b>";
$customname ="<b>PrinterCustomSupport</b>";
 ?>