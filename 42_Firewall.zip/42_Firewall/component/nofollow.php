

<meta name="robots" content="index">
<meta name="googlebot" content="index">
<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "WebSite",
  "name": "printercustomsupport.com",
  "url": "https://printercustomsupport.com/",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://printercustomsupport.com/{search_term_string}https://printercustomsupport.com/",
    "query-input": "required name=search_term_string"
  }
}
</script>
