<?php include 'common_header_info.php';?>






	<div class=" border  border  border-left-0 border-right-0  " style="background-image: linear-gradient(to right, #243949 0%, #517fa4 100%);">
		<div class=" border border-top-0 border-left-0 border-right-0 border-bottom-2">
		<div class="container-fluid mt-3">
			<p class="text-light text-left" >Country/Region: &nbsp;<img src="assets/img/us-flag.png" alt="US Flag-icon"> United States</p>
			
		</div>
	</div>
	<div class="container text-white text-wrap mt-2">
		
		<div class="row pb-5">
			<div class="col-md-4 text-left "> 
				<p class="text-left mb-0 text-white">Useful Links </p>
  <a class="nav-link text-light" href="<?=  $siteurl == true ? $siteurl :'' ?>"> 
    <i class="fa fa-home" aria-hidden="true"></i>&nbsp; Home </a>
	
    <a class="nav-link text-light" href="#serve">
    <i class="fa fa-users" aria-hidden="true"></i>&nbsp; About US  </a>
    <a class="nav-link text-light" href="sitemap.xml"> 
    <i class="fa fa-sitemap" aria-hidden="true"></i>&nbsp; Sitemap </a>
		
			</div>
			
<div class="col-md-4 text-left "> 
<p class="text-left mb-0 text-white"> Explore</p> 

<a class="nav-link text-light" href="privacy.php"> &nbsp;  Privacy Policy </a>
<a class="nav-link text-light" href="terms.php">&nbsp;Terms & Conditions </a>
	
			</div>
			
			
				
			<div class="col-md-4">
			  <p class="text-white">  Address:	</p>	
				<address  class="text-justify " style="font-size:12px;" >
				3133 W KNOB HILL ST, SPRINGFIELD, <br>MO 65810, United States </address>
				<address>
<i class="fa fa-envelope-o" aria-hidden="true"></i> Email:
<a href="mailto:info@printercustomsupport.com" class="text-light">info@printercustomsupport.com  </a><br>


<i class="fa fa-globe" aria-hidden="true"></i> Website: <a href="<?=  $siteurl == true ? $siteurl :'' ?>" class="text-light"> printercustomsupport.com </a><br>


</address>
			</div>
				</div>
				
	
	
	<!-- 			<div class="social-links social-icons text-center my-2">
						<a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
					<a href="https://twitter.com/"><i class="fa fa-twitter"></i></a>
					<a href="https://tumblr.com/"><i class="fa fa-tumblr"></i></a>
					<a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
					<a href="https://in.pinterest.com/"><i class="fa fa-pinterest-p"></i></a>
				
			
			
				</div> -->
				
			</div>   <!-- footer Container end -->
		
	</div>
	
	<p class="mb-0 text-center py-3 text-white " style=" background-image: linear-gradient(to right, #243949 0%, #517fa4 100%);" >Copyright © <?= date('Y')?> <a href="<?=  $siteurl == true ? $siteurl :'' ?>" class="text-white" >printercustomsupport.com</a>, All rights reserved </p>